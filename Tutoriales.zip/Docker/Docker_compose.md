# Docker compose

Docker compose es la manera que utiliza docker para poder crear contenedores o grupos de contenedores.


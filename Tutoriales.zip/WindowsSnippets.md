# Windows Snippets





>Borrar clave ssh 
>
>`ssh-keygen -R "ip"`